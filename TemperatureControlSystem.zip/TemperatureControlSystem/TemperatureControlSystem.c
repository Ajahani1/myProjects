//Title:Temperature control project for MCO455
//Author: Anique Jahani 032-167-116
//Date: 11/29/2016
//Description: This project will function as a temperature control system. 
//The user will control the system by setting a particular temperature.  
//Based on this value the program will indicate heating, fan and cooling using leds. 
//The temperature is written using a D/A converter and then read onto an A/D converter. 
//The set point and temperature values will be displays on the 7-segmant displays, lCD and hyper terminal screen. 
//The heating, cooling, and fan will also be displays on both hyper terminal screen and LCD.

//include section
#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */
#include "C:\TEMP\library_files\library_de1.h" //includes arduino-like functions

//global variables section
volatile unsigned char temp; //indicates temperature
volatile unsigned char setPoint; //indicates setpoint temperature
const unsigned char minTemp=10; //sets minimum temperature
const unsigned char maxTemp=35; //sets max temperature
const unsigned char numbers[]={0x02, 0x9e, 0x24, 0x0c, 0x98, 0x48, 0x40, 0x1e, 0x00, 0x18}; //array of digits from 0-9 dec in hex

//function prototypes
void sci_1_init (void); 
void initLCD (void); //function responsible for initilizing lcd
void hyperScreen (void); //function responsible for initializing hyperterminal  
void initHex (void); //function responsible for initializing 7-seg hex display
void updateValues (void); //function responsible for updating lcd and hyperterminal with values
void increase (void); //function responsible for increasing setpoint
void decrease (void); //function responsible for decreasing setpoint
void optimize (void); //function responsible for displaying heating, fan, cooling on lcd, LEDs and hyperterminal

void main(void) 
{
	SOPT_COPE=0; /* disable COP */
	setPoint=0x14;	//set point to 20 deg
	temp=0x14;	//temperature to 20 deg
	LCD_ROWS=4; //sets rows to 4 on lcd
	LCD_COLS=16;  //sets columns to 16 on lcd
	devices_init(); // initialize all devices
	sci_1_init();
	sci_init(); //initializes SCI enables Tx and Rx
	scr_clear(); //will clear all displays
	initLCD();
	hyperScreen();
	initHex();	 
	updateValues();	 
	analog_write_int(1,temp<<4); //will write the current temperature to TP8 using D/A
	for (;;)
	{
		initHex();
		increase();
		decrease();
		optimize();
		temp=((analog_read_int(1))>>4); //will read back TP10 and converts to digital value
		updateValues();
	}
}

void sci_1_init(void)
{
	SCI1BDL=0X82;
	SCI1C2=0X0c;
}

void initLCD (void)
{
	lcd_setcursor(0,0); //sets LCD cursor
	lcd_print("TEMP"); //prints the message "temp" on LCD
	lcd_setcursor(0,5); //sets LCD cursor
	lcd_print("Ctrl"); //prints the message "ctrl" on LCD
	lcd_setcursor(0,10); //sets LCD cursor
	lcd_print("System"); //prints the message "system" on LCD
	lcd_setcursor(1,0); //sets LCD cursor
	lcd_print("StPT"); //prints the message "stpt" on LCD
	lcd_setcursor(1,7); //sets LCD cursor
	lcd_writech(0xDF); //degree symbol
	lcd_setcursor(1,9); //sets LCD cursor
	lcd_print("Tmp"); //prints the message "tmp" on LCD
	lcd_setcursor(1,15);    //sets LCD cursor
    lcd_writech(0xDF);      //degree symbol
    lcd_setcursor(2,0);     //sets LCD cursor
    lcd_print("HTR");       //prints the message "htr" on LCD
    lcd_setcursor(2,6);     //sets LCD cursor
    lcd_print("FAN");       //prints the message "fan" on LCD
    lcd_setcursor(2,11);    //sets LCD cursor
    lcd_print("Cool"); //prints the message "cool" on LCD
}

void hyperScreen (void)
{
	scr_clear(); //clears the screen
	scr_setcursor(1,18); //sets cursor on hyperterminal 
	scr_print("TEMPERATURE CONTROL SYSTEM MONITOR PROGRAM"); //prints the text on hyper terminal screen
	scr_setcursor(3,32); //sets cursor on hyperterminal
	scr_print("LOCAL SYSTEM"); //prints the text on hyper terminal screen
	scr_setcursor(6,18); //sets cursor on hyperterminal
	scr_print("SETPOINT TEMPERATURE  TEMPERATURE READING"); //prints the text on hyper terminal screen
	scr_setcursor(9,15); //sets cursor on hyperterminal
	scr_print("HEATING SYSTEM         FAN          COOLING SYSTEM"); //prints the text on hyper terminal screen
}

void initHex (void)
{
	HEX3=numbers[hex2dec(setPoint)>>4];      //first digit of set point sent to 7seg display
    HEX2=numbers[hex2dec(setPoint)&0x0f];    //second digit of set point sent to 7seg display
    HEX1=numbers[hex2dec(temp)>>4];   //first digit of temp sent to 7seg display
    HEX0=numbers[hex2dec(temp)&0x0f];  //second digit of temp sent to 7seg display
}

void updateValues (void)
{
		scr_setcursor(7,25);                //sets cursor on hyper terminal
	   scr_write(hex2dec(setPoint));       //will show initial value of set point on hyperterminal
	   lcd_setcursor(1,5);                 //sets LCD cursor
	   lcd_write(hex2dec(setPoint));       //will show initial value of set point on LCD
	   scr_setcursor(7,55);                //sets cursor on hyper terminal
	   scr_write(hex2dec(temp));    //will show initial value of temp on hyperterminak
	   lcd_setcursor(1,13);                //sets LCD cursor
	   lcd_write(hex2dec(temp));    //will show inital value of temp on lcd
}

void increase (void)
{
	while((SW_KEY3==1)&&(SW_KEY2==0)) //while loop to ensure sw_key3 is pressed
    {
        if(setPoint<maxTemp)          //if statement to check if setpoint is less than 35
            setPoint++;               //setpoint increase
        delay_milli(200);             //delays by 200ms
        initHex();                
        updateValues();            
    }
}

void decrease (void)
{
	 while((SW_KEY3==0)&&(SW_KEY2==1)) //while loop to ensure sw_key2 is pressed
    {
        if(setPoint>minTemp)         //if statement to check if setpoint is greater than 10
            setPoint--;               //setpoint decrease
        delay_milli(200);             //delays by 200ms
        initHex();                
        updateValues();	          
    }
}

void optimize (void)
{
	if(setPoint>temp) //if setpoint is greater than temperature
    {
        LEDR_LED0=0xFF;            //heater on
        LEDG_LED5=0xFF;            //fan on
        LEDG_LED7=0x00;            //cooling off
        lcd_setcursor(3,1);     //sets LCD cursor
        lcd_print("ON");       //prints the message on lcd
        scr_setcursor(10,20);    //sets cursor on hyper terminal
        scr_print("ON");       //prints the message on hyperterminal
        lcd_setcursor(3,7);     //sets LCD cursor
        lcd_print("ON");       //prints the message on lcd
        scr_setcursor(10,39);    //sets cursor on hyper terminal
        scr_print("ON");       //prints the message on hyperterminal
        lcd_setcursor(3,12);  //sets LCD cursor
        lcd_print("off");       //prints the message on lcd
        scr_setcursor(10,53);    //sets cursor on hyper terminal
        scr_print("off");       //prints the message on hyperterminal
        delay_milli(1000);	    //will waste 1000ms
        temp++;		    //temperature increase
        analog_write_int(1,temp<<4);  //will send temperature value to TP8 and shifts bits
    }
    else 
		if(setPoint<temp) //if setpoint is les than temperature
    	{
        	LEDR_LED0=0x00;            //heater off
        	LEDG_LED5=0xFF;            //fan on
        	LEDG_LED7=0XFF;            //cooling on
        	lcd_setcursor(3,1);     //sets LCD cursor
        	lcd_print("off");        //prints the message on lcd
        	scr_setcursor(10,20);    //sets cursor on hyper terminal
        	scr_print("off");      //prints the message on hyperterminal
        	lcd_setcursor(3,7);     //sets LCD cursor
        	lcd_print("ON ");        //prints the message on lcd
        	scr_setcursor(10,39);    //sets cursor on hyper terminal
        	scr_print("ON ");       //prints the message on hyperterminal
        	lcd_setcursor(3,12);    //sets LCD cursor
        	lcd_print("ON ");        //prints the message on lcd
        	scr_setcursor(10,53);    //sets cursor on hyper terminal
        	scr_print("ON ");       //prints the message on hyperterminal
        	delay_milli(1000);	    //wastes 1000ms
        	temp--;		    //temperature decreases
        	analog_write_int(1,temp<<4);  //sends temp to TP8 and shift bits
    	}
    else
    {
        LEDR_LED0=0x00;            //heater off
        LEDG_LED5=0x00;            //fan off
        LEDG_LED7=0x00;            //cooling off
        lcd_setcursor(3,1);     //sets cursor on lcd 
        lcd_print("off");       //prints the message on lcd
        scr_setcursor(10,20);    //sets cursor on hyper terminal
        scr_print("off");       //prints the message on hyperterminal
        lcd_setcursor(3,7);     //sets cursor on lcd 
        lcd_print("off");        //prints the message on lcd
        scr_setcursor(10,39);    //sets cursor on hyper terminal
        scr_print("off");       //prints the message on hyperterminal
        lcd_setcursor(3,12);    //sets cursor on lcd
        lcd_print("off");        //prints the message on lcd
        scr_setcursor(10,53);    //sets cursor on hyper terminal
        scr_print("off");       //prints the message on hyperterminal
    }
}
